# -*- coding: utf-8 -*-

admin_id =  1068175354# ID главного админа
admin_two =  1068175354
tokenQiwi = 'токен' # Токен от киви
number =  +номер# Номер от киви
token ='1725103489:AAFZuJw_-4Na37fxNv_sx5HZE83TfhIuNr0' # Токен BotFather
bot_login = 'Blackjack666_bot'
linkTg ='@deanonparnisha' # Телеграм главного админа
urlPay = 'https://qiwi.com/payment/form/99?extra[%27account%27]={num}&amountFraction=0&currency=643&extra[%27comment%27]={com}&blocked[1]=account&blocked[2]=comment' # ссылка с заполенными полями Qiwi
linkLogs ='https://t.me/logs_black' # Ссылка на чат с логами
linkMoney ='https://t.me/dep_blackjack' # Ссылка на чат с выплатами
chatUsers ='https://t.me/black_chat_jack' # Ссылка на чат с пользователями
idMoney = -1001447126355# id telegram канала с выплатами где бот администратор
idLogs = -1001494603389 # id telegram канала с логами где бот администратор

min_game = 10
ref_percent = 2 
#слито в @smoke_software